/**
 * Chrome extension named S4L is used to save opened tabs for later surfing
 */

var doNotAddListener = true;